import express from "express";
import fetch from "node-fetch";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
if (!OPENAI_API_KEY) console.warn("⚠️ OPENAI_API_KEY missing. Set it in your host env.");

/**
 * POST /analyze
 * Body: { symbol, timeframe, strategy, candles: [{time,open,high,low,close,volume}], features }
 * Returns: { tag: 'BUY|SELL|HOLD', signal: '...', explained: '...' }
 */
app.post("/analyze", async (req, res) => {
  try {
    const { symbol, timeframe, strategy, candles, features, latest } = req.body;

    const prompt = [
      `You are MiguelFx AI, a disciplined trading assistant.`,
      `Symbol: ${symbol} | TF: ${timeframe} | Strategy: ${strategy}`,
      `Recent candles (old->new): ${JSON.stringify(candles.slice(-60))}`,
      `Helper features (last values): ${JSON.stringify(features)}`,
      `Goal: Return a single JSON object with fields: tag (BUY/SELL/HOLD), signal (one-line summary), explained (bullets: entry, stop, TP, rationale).`,
      `Rules:`,
      `- Risk ~1% of equity; give stop distance logic.`, 
      `- Respect the selected strategy:`,
      `  - ICT/SMC: focus on market structure, liquidity sweeps, fair value gaps, order blocks, BOS/CHOCH.`,
      `  - TRENDLINE: identify trend direction; signal on clean break/retest with volume/structure confluence.`,
      `  - EMA_RSI: EMA(20/50) cross and RSI(14) overbought/oversold confluence.`,
      `  - BREAKOUT_ATR: mark range high/low; entry on breakout; SL = 1*ATR(14) beyond level.`,
      `- Use the provided candles (don’t invent prices). If data is insufficient, return HOLD.`,
      `Format strictly as minified JSON (no extra commentary).`
    ].join("\n");

    const oa = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You respond with strict JSON only, no prose." },
          { role: "user", content: prompt }
        ],
        temperature: 0.2
      })
    });

    if (!oa.ok) {
      const t = await oa.text();
      console.error("OpenAI error:", t);
      return res.status(500).json({ error: "OpenAI request failed" });
    }

    const data = await oa.json();
    let content = data.choices?.[0]?.message?.content || "{}";
    // Ensure valid JSON
    try {
      const parsed = JSON.parse(content);
      return res.json(parsed);
    } catch (e) {
      // Fallback: wrap common mistakes
      content = content.trim();
      if (content.startsWith("```")) {
        content = content.replace(/```(json)?/g, "").trim();
      }
      try {
        const parsed2 = JSON.parse(content);
        return res.json(parsed2);
      } catch (e2) {
        return res.json({ tag: "HOLD", signal: "Model returned non-JSON", explained: content.slice(0,400) });
      }
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`MiguelFx AI backend running on ${PORT}`));
