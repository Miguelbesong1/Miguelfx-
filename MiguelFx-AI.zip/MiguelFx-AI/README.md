# MiguelFx AI

A professional trading assistant with a **live TradingView chart** and an **AI backend** that analyzes recent candles and returns BUY/SELL/HOLD, using a chosen strategy (ICT, SMC, Trendline, EMA+RSI, Breakout+ATR).

## Structure
```
frontend/  -> static site (Netlify/Vercel)
backend/   -> Node.js proxy (Render/Railway/Heroku) — keeps OpenAI key safe
```

## Backend (secure AI proxy)
```
cd backend
npm install
# Set OpenAI key in your environment (never commit it)
export OPENAI_API_KEY="sk-..."
npm start
```
Deploy on Render/Railway/Heroku and set env var `OPENAI_API_KEY` there.

## Frontend
- Open `frontend/script.js` and set:
  - `BACKEND_URL` to your deployed backend (e.g. https://your-backend.onrender.com)
  - `TWELVE_API_KEY` to your TwelveData key
- Deploy `frontend/` folder to Netlify/Vercel

## How it works
- TradingView widget shows **live** price stream.
- Frontend fetches recent candles from **TwelveData** (time_series endpoint).
- Frontend sends candles + chosen **strategy** to backend `/analyze`.
- Backend asks OpenAI to return strict JSON: `{tag, signal, explained}`.
- Frontend displays a colored badge + rationale and updates timestamp.

## Notes
- TwelveData symbols used: EUR/USD, XAU/USD, BTC/USD, EUR/CAD (mapped from TradingView selector).
- Add more symbols by editing `index.html` options and mapping in `script.js`.
- Journal is local-only (in-memory). For persistence, wire it to your backend later.
