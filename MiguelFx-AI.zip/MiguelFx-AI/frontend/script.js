// MiguelFx AI Frontend
// IMPORTANT: Replace with your deployed backend URL (Render/Railway/Heroku)
const BACKEND_URL = "http://localhost:3000"; // e.g., https://your-backend.onrender.com
// TwelveData API key (frontend-visible; fine to keep here)
const TWELVE_API_KEY = "REPLACE_WITH_YOUR_TWELVEDATA_KEY";

// --- TradingView chart setup (live) ---
let tvWidget;
function loadChart(symbol, timeframe) {
  // Destroy previous if exists
  const container = document.getElementById("tradingview-widget");
  container.innerHTML = "";
  tvWidget = new TradingView.widget({
    width: "100%",
    height: 520,
    symbol,
    interval: timeframe,
    timezone: "Etc/UTC",
    theme: "dark",
    style: "1",
    locale: "en",
    hide_side_toolbar: false,
    allow_symbol_change: false,
    container_id: "tradingview-widget",
  });
}

// Map TradingView symbol to TwelveData symbol
function tdSymbolFromTV(tvSymbol) {
  const el = document.querySelector(`#symbolSelect option[value='${tvSymbol}']`);
  return el ? el.getAttribute("data-td") : "EUR/USD";
}

// --- Data fetch from TwelveData (candles) ---
async function fetchCandles(tdSymbol, interval, limit=120) {
  // Map interval
  const map = { "15": "15min", "60": "1h", "240": "4h", "D": "1day" };
  const intStr = map[interval] || "15min";
  const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(tdSymbol)}&interval=${intStr}&apikey=${encodeURIComponent(TWELVE_API_KEY)}&outputsize=${limit}&format=JSON`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("TwelveData error: " + res.status);
  const data = await res.json();
  if (data && data.values) {
    // Ensure latest->oldest ordering for our calc
    return data.values.map(v => ({
      time: v.datetime,
      open: +v.open, high: +v.high, low: +v.low, close: +v.close, volume: +v.volume
    })).reverse();
  } else {
    return [];
  }
}

// --- Indicators (client-side helpers) ---
function ema(values, period, accessor = v => v) {
  const k = 2 / (period + 1);
  let emaArr = [];
  let prev;
  values.forEach((v, i) => {
    const val = accessor(v);
    if (i === 0) prev = val;
    prev = val * k + prev * (1 - k);
    emaArr.push(prev);
  });
  return emaArr;
}
function rsi(values, period=14, accessor = v => v) {
  let gains = 0, losses = 0;
  let rsis = Array(values.length).fill(null);
  for (let i=1;i<values.length;i++) {
    const change = accessor(values[i]) - accessor(values[i-1]);
    if (i <= period) {
      if (change >= 0) gains += change; else losses -= change;
      if (i === period) {
        let avgGain = gains/period, avgLoss = losses/period;
        let rs = avgLoss === 0 ? 100 : avgGain/avgLoss;
        rsis[i] = 100 - (100/(1+rs));
      }
    } else {
      let gain = change > 0 ? change : 0;
      let loss = change < 0 ? -change : 0;
      let prevAvgGain = (rsis[i-1] !== null) ? null : null; // placeholder
    }
  }
  // Simpler RSI using close-to-close Wilder smoothing
  let avgGain = 0, avgLoss = 0;
  for (let i=1;i<values.length;i++) {
    const change = accessor(values[i]) - accessor(values[i-1]);
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? -change : 0;
    if (i <= period) {
      avgGain += gain; avgLoss += loss;
      if (i === period) {
        avgGain /= period; avgLoss /= period;
        let rs = avgLoss === 0 ? 100 : avgGain/avgLoss;
        rsis[i] = 100 - 100/(1+rs);
      }
    } else {
      avgGain = (avgGain*(period-1) + gain) / period;
      avgLoss = (avgLoss*(period-1) + loss) / period;
      let rs = avgLoss === 0 ? 100 : avgGain/avgLoss;
      rsis[i] = 100 - 100/(1+rs);
    }
  }
  return rsis;
}
function atr(candles, period=14) {
  if (candles.length < 2) return [];
  const trs = [null]; // TR for first is undefined
  for (let i=1;i<candles.length;i++) {
    const c = candles[i], p = candles[i-1];
    const tr = Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
    trs.push(tr);
  }
  // Wilder smoothing
  let atrs = Array(candles.length).fill(null);
  let sum = 0;
  for (let i=1;i<=period;i++) sum += trs[i] || 0;
  atrs[period] = sum/period;
  for (let i=period+1;i<trs.length;i++) {
    atrs[i] = (atrs[i-1]*(period-1) + trs[i]) / period;
  }
  return atrs;
}

// --- UI wiring ---
const symbolSel = document.getElementById("symbolSelect");
const tfSel = document.getElementById("tfSelect");
const strategySel = document.getElementById("strategySelect");
const signalBadge = document.getElementById("signalBadge");
const signalText = document.getElementById("signalText");
const meta = document.getElementById("meta");

function setBadge(type) {
  signalBadge.className = "badge " + type;
  signalBadge.textContent = type === "buy" ? "BUY" : type === "sell" ? "SELL" : type === "hold" ? "HOLD" : "No Signal";
}

async function analyze() {
  const tvSymbol = symbolSel.value;
  const tdSymbol = tdSymbolFromTV(tvSymbol);
  const tf = tfSel.value;
  const strategy = strategySel.value;

  signalText.textContent = "Analyzing…";
  setBadge("neutral");

  try {
    const candles = await fetchCandles(tdSymbol, tf, 200);
    if (!candles.length) {
      signalText.textContent = "No data from TwelveData. Check API key or symbol.";
      return;
    }

    // Build helper features for AI (optional)
    const closes = candles.map(c => c.close);
    const ema20 = ema(candles, 20, c => c.close);
    const ema50 = ema(candles, 50, c => c.close);
    const rsi14 = rsi(candles, 14, c => c.close);
    const atr14 = atr(candles, 14);

    const payload = {
      symbol: tdSymbol,
      timeframe: tf,
      strategy,
      latest: candles[candles.length-1],
      candles: candles.slice(-120), // send last 120 to keep payload small
      features: {
        ema20: ema20.slice(-5),
        ema50: ema50.slice(-5),
        rsi14: rsi14.slice(-5),
        atr14: atr14.slice(-5)
      }
    };

    const res = await fetch(`${BACKEND_URL}/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!res.ok) throw new Error("Backend error " + res.status);
    const data = await res.json();

    signalText.textContent = data.explained ?? data.signal ?? "No response";
    const tag = (data.tag || "").toLowerCase();
    setBadge(tag === "buy" || tag === "long" ? "buy" : tag === "sell" || tag === "short" ? "sell" : tag === "hold" ? "hold" : "neutral");
    meta.textContent = `Strategy: ${strategy} • TF: ${tf} • Updated: ${new Date().toLocaleString()}`;
  } catch (e) {
    console.error(e);
    signalText.textContent = "Error during analysis. Check BACKEND_URL and keys.";
    setBadge("neutral");
  }
}

document.getElementById("analyzeBtn").addEventListener("click", analyze);

// React to selection changes
symbolSel.addEventListener("change", () => loadChart(symbolSel.value, tfSel.value));
tfSel.addEventListener("change", () => loadChart(symbolSel.value, tfSel.value));

// Journal saving
const jForm = document.getElementById("journalForm");
const jList = document.getElementById("journalList");
jForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const item = {
    sym: document.getElementById("jSymbol").value,
    entry: document.getElementById("jEntry").value,
    exit: document.getElementById("jExit").value,
    stop: document.getElementById("jStop").value,
    notes: document.getElementById("jNotes").value,
    time: new Date().toISOString()
  };
  const li = document.createElement("li");
  li.textContent = `${item.time.slice(0,19).replace('T',' ')} — ${item.sym} | Entry ${item.entry} | Exit ${item.exit} | SL ${item.stop} | ${item.notes}`;
  jList.prepend(li);
  jForm.reset();
});

// Initial load
loadChart(symbolSel.value, tfSel.value);
