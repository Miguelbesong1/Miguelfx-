import express from "express";
import cors from "cors";
import fetch from "node-fetch";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8787;
const TD_KEY = process.env.TWELVEDATA_API_KEY || "";
app.use(express.json({ limit: "1mb" }));
app.use(cors());

// Indicators
function sma(values, period){const r=[];for(let i=0;i<values.length;i++){if(i+1<period){r.push(null);continue;}const s=values.slice(i+1-period,i+1).reduce((a,b)=>a+Number(b),0);r.push(s/period);}return r;}
function rsi(closes, p=14){let g=0,l=0;const rsis=new Array(closes.length).fill(null);for(let i=1;i<=p;i++){const ch=closes[i]-closes[i-1];if(ch>=0)g+=ch;else l-=ch;}let ag=g/p, al=l/p;rsis[p]=al===0?100:100-(100/(1+(ag/al)));for(let i=p+1;i<closes.length;i++){const ch=closes[i]-closes[i-1];const gn=Math.max(ch,0);const ls=Math.max(-ch,0);ag=(ag*(p-1)+gn)/p;al=(al*(p-1)+ls)/p;const rs=al===0?1e6:ag/al;rsis[i]=100-(100/(1+rs));}return rsis;}
function atr(highs,lows,closes,p=14){const trs=[];for(let i=0;i<highs.length;i++){if(i===0){trs.push(highs[i]-lows[i]);continue;}const h=highs[i],lo=lows[i],pc=closes[i-1];trs.push(Math.max(h-lo,Math.abs(h-pc),Math.abs(lo-pc)));}const out=[];let sum=0;for(let i=0;i<trs.length;i++){sum+=trs[i];if(i<p)out.push(null);else if(i===p)out.push(sum/p);else{const prev=out[i-1];out.push((prev*(p-1)+trs[i])/p);} }return out;}

async function fetchSeries(symbol="EUR/USD", interval="15min", outputsize=300){
  const url=`https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${interval}&outputsize=${outputsize}&apikey=${TD_KEY}`;
  const r=await fetch(url); const j=await r.json();
  if(!j || !j.values) throw new Error(j?.message || "Bad TwelveData response");
  const values=[...j.values].reverse();
  return values.map(v=>({datetime:v.datetime,open:+v.open,high:+v.high,low:+v.low,close:+v.close,volume:+(v.volume||0)}));
}

function recentSwingHL(data, look=40){
  const highs=data.map(c=>c.high), lows=data.map(c=>c.low);
  const start=Math.max(2, highs.length-look); let H=null,L=null;
  for(let i=start;i<highs.length-2;i++){
    if(highs[i]>highs[i-1]&&highs[i]>highs[i-2]&&highs[i]>highs[i+1]&&highs[i]>highs[i+2]) H={i,price:highs[i]};
    if(lows[i]<lows[i-1]&&lows[i]<lows[i-2]&&lows[i]<lows[i+1]&&lows[i]<lows[i+2]) L={i,price:lows[i]};
  }
  return {H,L};
}

function base(data){
  const c=data.map(x=>x.close), h=data.map(x=>x.high), l=data.map(x=>x.low);
  return {
    last:c.at(-1),
    rsi14:rsi(c,14).at(-1),
    sma50:sma(c,50).at(-1),
    sma200:sma(c,200).at(-1),
    atr14:atr(h,l,c,14).at(-1)
  };
}

function decide(strategy, data){
  const {last,rsi14,sma50,sma200,atr14}=base(data);
  const recent=data.slice(-60); const hi=Math.max(...recent.map(c=>c.high)), lo=Math.min(...recent.map(c=>c.low));
  const {H,L}=recentSwingHL(data,40);
  let signal="HOLD", sl=null, tp=null, notes=[];
  const risk= atr14 || (hi-lo)/20 || (last*0.001);

  const set=(bias)=>{
    if(bias==="BUY"){ sl=+(last-1.2*risk).toFixed(5); tp=+(last+2.0*risk).toFixed(5); }
    if(bias==="SELL"){ sl=+(last+1.2*risk).toFixed(5); tp=+(last-2.0*risk).toFixed(5); }
  };

  switch((strategy||"").toLowerCase()){
    case "rsi":
      if(rsi14>55){signal="BUY";notes.push("RSI>55 bullish");}
      else if(rsi14<45){signal="SELL";notes.push("RSI<45 bearish");}
      set(signal); break;
    case "sma":
      if(sma50&&sma200){
        if(sma50>sma200 && last>sma50){signal="BUY";notes.push("Golden + above 50");}
        if(sma50<sma200 && last<sma50){signal="SELL";notes.push("Death + below 50");}
      }
      set(signal); break;
    case "trendline":
      if(L && last > L.price + (risk*0.2)){signal="BUY";notes.push("Bounce above swing low");}
      if(H && last < H.price - (risk*0.2)){signal="SELL";notes.push("Rejection below swing high");}
      set(signal); break;
    case "headshoulders":
      const arr=data.slice(-30);
      const idx=arr.findIndex((c,i)=>i>3&&i<arr.length-3&&c.high>arr[i-1].high&&c.high>arr[i-2].high&&c.high>arr[i+1].high&&c.high>arr[i+2].high);
      if(idx>2 && idx<arr.length-3){
        const left=Math.max(arr[idx-3].high,arr[idx-2].high), right=Math.max(arr[idx+2].high,arr[idx+3].high);
        const head=arr[idx].high;
        const neckline=(Math.min(arr[idx-2].low,arr[idx-1].low)+Math.min(arr[idx+1].low,arr[idx+2].low))/2;
        if(head>left && head>right && last<neckline){signal="SELL";notes.push("H&S neckline break");}
        if(head<left && head<right && last>neckline){signal="BUY";notes.push("Inverse H&S break");}
      }
      set(signal); break;
    case "smc":
    case "ict":
      const n=8, seg=data.slice(-n); let up=0,down=0;
      for(let i=1;i<seg.length;i++){ if(seg[i].high>seg[i-1].high && seg[i].low>seg[i-1].low) up++; if(seg[i].high<seg[i-1].high && seg[i].low<seg[i-1].low) down++; }
      if(up>=Math.ceil(n*0.4)){signal="BUY";notes.push("HH/HL structure");}
      if(down>=Math.ceil(n*0.4)){signal="SELL";notes.push("LH/LL structure");}
      set(signal); break;
    case "breakout":
      if(last>hi){signal="BUY";notes.push("Breakout 60-bar high");}
      else if(last<lo){signal="SELL";notes.push("Breakdown 60-bar low");}
      set(signal); break;
    default:
      let bull=0,bear=0;
      if(rsi14>55) bull++; if(rsi14<45) bear++;
      if(sma50&&sma200){ if(sma50>sma200&&last>sma50) bull++; if(sma50<sma200&&last<sma50) bear++; }
      signal = bull>bear ? "BUY" : bull<bear ? "SELL" : "HOLD";
      set(signal);
  }
  return {signal, stopLoss:sl, takeProfit:tp, rsi14,sma50,sma200,atr14,last, notes};
}

app.get("/api/metrics", async (req,res)=>{
  try{
    const {symbol="EUR/USD", interval="15min"} = req.query;
    const data = await fetchSeries(symbol, interval, 300);
    const {last,rsi14,sma50,sma200,atr14} = base(data);
    res.json({last,rsi14,sma50,sma200,atr14});
  }catch(e){ res.status(500).json({error:e.message}); }
});

app.post("/api/analyze", async (req,res)=>{
  try{
    const {symbol="EUR/USD", interval="15min", strategy="rsi"} = req.body || {};
    const data = await fetchSeries(symbol, interval, 300);
    const result = decide(strategy, data);

    // Optional OpenAI rationale
    let rationale = "";
    if (process.env.OPENAI_API_KEY){
      try {
        const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
        const completion = await client.chat.completions.create({
          model: "gpt-4o-mini",
          messages: [{role:"user", content:`Give a one-sentence reason for ${strategy} → ${result.signal} using: RSI ${result.rsi14?.toFixed?.(2)}, SMA50 ${result.sma50?.toFixed?.(5)}, SMA200 ${result.sma200?.toFixed?.(5)}, ATR ${result.atr14?.toFixed?.(5)}, notes: ${result.notes.join(", ")}`}],
          temperature: 0.2
        });
        rationale = completion.choices?.[0]?.message?.content || "";
      } catch {}
    }

    res.json({...result, rationale});
  }catch(e){ res.status(500).json({error:e.message}); }
});

app.listen(PORT, ()=>console.log(`Miguel FX Pro API on :${PORT}`));
