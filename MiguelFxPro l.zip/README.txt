# Miguel FX Pro
- Frontend (web/) is static (TradingView + controls).
- Backend (server/) fetches TwelveData, computes multiple strategies, adds OpenAI rationale, and returns a secure signal.
See server/.env.example for required env vars.
