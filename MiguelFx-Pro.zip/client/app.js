const q = id => document.getElementById(id);

function tvTF(v){ return v==="15min"?"15":v==="1h"?"60":v==="4h"?"240":"D"; }

function loadTV(){
  const opt = document.querySelector("#symbol option:checked");
  const tvSym = opt.dataset.tv;
  const tf = tvTF(q("interval").value);
  q("tvLabel").textContent = tvSym;
  q("tvTF").textContent = tf;
  const c = document.getElementById("tvWidget");
  c.innerHTML = "";
  new TradingView.widget({
    symbol: tvSym, interval: tf, container_id: "tvWidget",
    width: "100%", height: 520, timezone: "Etc/UTC", theme: "dark", style: "1", locale: "en",
    hide_side_toolbar: false, allow_symbol_change: false
  });
}

function setBadge(tag, msg){
  const b=q("sigBadge");
  b.className = "badge " + (tag==="BUY"?"buy":tag==="SELL"?"sell":tag==="HOLD"?"hold":"");
  b.textContent = tag;
  q("sigText").textContent = msg;
}

async function analyze(){
  try{
    setBadge("HOLD","Analyzing…");
    const symbol=q("symbol").value;
    const interval=q("interval").value;
    const strategy=q("strategy").value;
    const r = await fetch("/api/analyze", {
      method:"POST", headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ symbol, interval, strategy })
    });
    const j = await r.json();
    if(!r.ok) throw new Error(j.error || "Server error");
    const base = j.baseline;
    const msg = `${base.tag} @ ${fmt(base.entry)} | SL ${fmt(base.sl)} | TP ${fmt(base.tp)} — ${base.note}\n${j.ai}`;
    setBadge(base.tag, msg);
    addHistory(`${new Date().toLocaleString()} • ${symbol} ${interval} • ${base.tag} @ ${fmt(base.entry)} SL ${fmt(base.sl)} TP ${fmt(base.tp)} — ${base.note}`);

    // Quick metrics
    const cr = await fetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&limit=240`);
    const cj = await cr.json();
    if(cr.ok && cj.candles?.length){
      const c = cj.candles;
      q("mLast").textContent = fmt(c.at(-1).close);
      const rsi = RSI(c,14).at(-1);
      q("mRSI").textContent = rsi? rsi.toFixed(2):"—";
      q("mSMA50").textContent = fmt(SMA(c,50, x=>x.close).at(-1));
      q("mSMA200").textContent = fmt(SMA(c,200, x=>x.close).at(-1));
    }
  }catch(e){ setBadge("HOLD", e.message); }
}

function addHistory(t){ const li=document.createElement("li"); li.textContent = t; q("log").prepend(li); }
q("clear").onclick = ()=> q("log").innerHTML = "";

function fmt(v){ if(v==null) return "—"; return Math.abs(v)>100? v.toFixed(2): v.toFixed(5); }

// lightweight indicators in client
function SMA(arr,p,acc=x=>x){ return arr.map((_,i)=> i<p-1? null : (arr.slice(i-p+1,i+1).reduce((s,v)=>s+acc(v),0)/p) ); }
function RSI(c,p=14){
  const close=c.map(x=>x.close), out=Array(close.length).fill(null);
  if(close.length<p+1) return out;
  let g=0,l=0; for(let i=1;i<=p;i++){ const d=close[i]-close[i-1]; g+=Math.max(0,d); l+=Math.max(0,-d); }
  let avgG=g/p, avgL=l/p; out[p]=100-100/(1+(avgL===0?100:avgG/avgL));
  for(let i=p+1;i<close.length;i++){ const d=close[i]-close[i-1]; const up=Math.max(0,d), dn=Math.max(0,-d);
    avgG=(avgG*(p-1)+up)/p; avgL=(avgL*(p-1)+dn)/p;
    out[i]=100-100/(1+(avgL===0?100:avgG/avgL));
  } return out;
}

// Events
q("symbol").onchange = loadTV;
q("interval").onchange = loadTV;
q("reload").onclick = loadTV;
q("analyze").onclick = analyze;

// Auto refresh
let t=null;
q("auto").onchange = ()=>{ if(t){clearInterval(t);t=null;} if(q("auto").checked){ const s=parseInt(q("every").value); t=setInterval(analyze, s*1000);} };
q("every").onchange = ()=>{ if(q("auto").checked){ if(t){clearInterval(t);} t=setInterval(analyze, parseInt(q("every").value)*1000);} };

// Init
loadTV();
