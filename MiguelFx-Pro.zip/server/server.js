import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
dotenv.config();

const app = express();
const PORT = process.env.PORT || 8080;

app.use(helmet());
app.use(express.json({ limit: "1mb" }));

// CORS allowlist
const allowed = (process.env.CORS_ORIGIN || "http://localhost:8080,http://127.0.0.1:8080").split(",");
app.use(cors({
  origin: function (origin, cb) {
    if (!origin || allowed.indexOf(origin) !== -1) return cb(null, true);
    return cb(new Error("CORS blocked: " + origin));
  }
}));

// Basic rate limit
app.use("/api/", rateLimit({ windowMs: 60 * 1000, max: 60 }));

// Health
app.get("/api/health", (req,res)=> res.json({ ok:true, env:process.env.NODE_ENV||"dev", time:new Date().toISOString() }));

// ---- TwelveData proxy ----
const TD_BASE = "https://api.twelvedata.com/time_series";
function norm(values){
  return values.map(v => ({ time:v.datetime, open:+v.open, high:+v.high, low:+v.low, close:+v.close, volume:+v.volume })).reverse();
}
app.get("/api/candles", async (req,res)=>{
  try{
    const symbol = req.query.symbol || "EUR/USD";
    const interval = req.query.interval || "15min";
    const outputsize = req.query.limit || "400";
    const key = process.env.TWELVEDATA_API_KEY;
    if (!key) return res.status(500).json({ error: "Missing TWELVEDATA_API_KEY" });
    const url = `${TD_BASE}?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&apikey=${encodeURIComponent(key)}&outputsize=${encodeURIComponent(outputsize)}&format=JSON`;
    const r = await fetch(url);
    if (!r.ok) return res.status(502).json({ error:"TwelveData HTTP " + r.status });
    const j = await r.json();
    if (!j.values) return res.status(502).json({ error: j.message || "No values" });
    res.json({ symbol, interval, candles: norm(j.values) });
  }catch(e){ res.status(500).json({ error:e.message }); }
});

// ---- Indicators & strategies ----
const SMA = (arr,p,acc=x=>x)=> arr.map((_,i)=> i<p-1 ? null : (arr.slice(i-p+1, i+1).reduce((s,v)=>s+acc(v),0)/p) );
function EMA(arr,p,acc=x=>x){
  const k=2/(p+1); let prev;
  return arr.map((v,i)=> prev = i ? acc(v)*k + prev*(1-k) : acc(v));
}
function RSI(c, p=14){
  const close=c.map(x=>x.close), out=Array(close.length).fill(null);
  if (close.length<p+1) return out;
  let g=0,l=0;
  for(let i=1;i<=p;i++){ const d=close[i]-close[i-1]; g+=Math.max(0,d); l+=Math.max(0,-d); }
  let avgG=g/p, avgL=l/p; out[p]=100-100/(1+(avgL===0?100:avgG/avgL));
  for(let i=p+1;i<close.length;i++){ const d=close[i]-close[i-1]; const up=Math.max(0,d), dn=Math.max(0,-d);
    avgG=(avgG*(p-1)+up)/p; avgL=(avgL*(p-1)+dn)/p;
    out[i]=100-100/(1+(avgL===0?100:avgG/avgL));
  }
  return out;
}
function ATR(c,p=14){
  const tr=[null];
  for(let i=1;i<c.length;i++){
    const cur=c[i], pr=c[i-1];
    tr.push(Math.max(cur.high-cur.low, Math.abs(cur.high-pr.close), Math.abs(cur.low-pr.close)));
  }
  const out=Array(c.length).fill(null);
  if (c.length<=p) return out;
  let sum=0; for(let i=1;i<=p;i++) sum+=tr[i]||0; out[p]=sum/p;
  for(let i=p+1;i<tr.length;i++) out[i]=(out[i-1]*(p-1)+tr[i])/p;
  return out;
}
function swingHi(c,i,L=2,R=2){ if(i<L||i>c.length-R-1) return false; for(let j=1;j<=L;j++) if(c[i].high<=c[i-j].high) return false; for(let j=1;j<=R;j++) if(c[i].high<=c[i+j].high) return false; return true; }
function swingLo(c,i,L=2,R=2){ if(i<L||i>c.length-R-1) return false; for(let j=1;j<=L;j++) if(c[i].low>=c[i-j].low) return false; for(let j=1;j<=R;j++) if(c[i].low>=c[i+j].low) return false; return true; }

// Head & Shoulders heuristic detector (returns {type:'H'|'I', points:[l,h,sh] or [r,ih,is]} or null)
function detectHnS(c){
  const idx = []; for(let i=0;i<c.length;i++) if(swingHi(c,i,2,2)||swingLo(c,i,2,2)) idx.push(i);
  if (idx.length<7) return null;
  // Use last ~80 bars
  const from = Math.max(0, c.length-80);
  const slice = c.slice(from);
  // Simple pattern: L-shoulder, Head higher, R-shoulder lower (bearish); inverse for bullish
  // We'll scan highs for bearish
  let best=null;
  for(let i=2;i<slice.length-2;i++){
    const a = slice[i-2], b = slice[i], d = slice[i+2];
    // Bearish H&S using highs
    if (a && b && d && a.high < b.high && d.high < b.high && Math.abs(a.high - d.high) / b.high < 0.02){
      best = { type:"H", l:i-2+from, h:i+from, r:i+2+from };
    }
    // Inverse using lows
    if (a && b && d && a.low > b.low && d.low > b.low && Math.abs(a.low - d.low) / b.low < 0.02){
      best = { type:"I", l:i-2+from, h:i+from, r:i+2+from };
    }
  }
  return best;
}

function lastStructure(c){
  // basic CHoCH/BOS style
  let up=false, down=false;
  for(let i=c.length-2;i>Math.max(1,c.length-40);i--){
    if(c[i].close>c[i-1].high) { up=true; break; }
    if(c[i].close<c[i-1].low) { down=true; break; }
  }
  if (up) return {dir:"up"}; if(down) return {dir:"down"}; return {dir:"none"};
}

function makeSignal(strategy, c){
  const i=c.length-1, price=c[i].close, a=ATR(c,14)[i] || (c[i].high-c[i].low)||0.0005;
  const pack=(tag,note)=>({ tag, entry:price, sl: tag==="BUY"? price-a : tag==="SELL"? price+a : null, tp: tag==="BUY"? price+2*a : tag==="SELL"? price-2*a : null, atr:a, note });
  if(strategy==="RSI"){
    const r=RSI(c,14)[i]; if(r==null) return pack("HOLD","RSI insufficient data");
    if(r>55) return pack("BUY",`RSI(14) ${r.toFixed(2)}>55`);
    if(r<45) return pack("SELL",`RSI(14) ${r.toFixed(2)}<45`);
    return pack("HOLD",`RSI(14) ${r.toFixed(2)}`);
  }
  if(strategy==="SMA"){
    const s50=SMA(c,50,x=>x.close)[i], s200=SMA(c,200,x=>x.close)[i];
    if(s50 && s200 && s50>s200 && price>s50) return pack("BUY",`SMA50>200 and price>SMA50`);
    if(s50 && s200 && s50<s200 && price<s50) return pack("SELL",`SMA50<200 and price<SMA50`);
    return pack("HOLD","No MA alignment");
  }
  if(strategy==="TRENDLINE"){
    const hi=[],lo=[]; for(let j=0;j<c.length;j++){ if(swingHi(c,j)) hi.push(j); if(swingLo(c,j)) lo.push(j); }
    if(hi.length<2||lo.length<2) return pack("HOLD","Not enough swings");
    const h1=hi.at(-1), h2=hi.at(-2), l1=lo.at(-1), l2=lo.at(-2);
    const res=(c[h1].high + (c[h1].high-c[h2].high)/(h1-h2) * (i-h1));
    const sup=(c[l1].low + (c[l1].low-c[l2].low)/(l1-l2) * (i-l1));
    if(price>res+0.2*a) return pack("BUY",`Break above trendline ~${res.toFixed(5)}`);
    if(price<sup-0.2*a) return pack("SELL",`Break below trendline ~${sup.toFixed(5)}`);
    return pack("HOLD","Inside TLs");
  }
  if(strategy==="ICT"||strategy==="SMC"){
    const st=lastStructure(c);
    if(st.dir==="up") return pack("BUY","BOS up (HH/HL bias)");
    if(st.dir==="down") return pack("SELL","BOS down (LH/LL bias)");
    return pack("HOLD","Range / no BOS");
  }
  if(strategy==="HEAD_SHOULDERS"){
    const p = detectHnS(c);
    if (p && p.type==="H") return pack("SELL","Bearish Head & Shoulders detected");
    if (p && p.type==="I") return pack("BUY","Inverse Head & Shoulders detected");
    return pack("HOLD","No clear H&S");
  }
  if(strategy==="BREAKOUT_ATR"){
    const look=60, arr=c.slice(-look);
    const hi=Math.max(...arr.map(x=>x.high)), lo=Math.min(...arr.map(x=>x.low));
    if(price>hi+0.1*a) return pack("BUY",`Breakout above ${hi.toFixed(5)}`);
    if(price<lo-0.1*a) return pack("SELL",`Breakdown below ${lo.toFixed(5)}`);
    return pack("HOLD","Inside range");
  }
  return pack("HOLD","Unknown strategy");
}

// ---- Analyze endpoint ----
app.post("/api/analyze", async (req,res)=>{
  try{
    const { symbol="EUR/USD", interval="15min", strategy="RSI" } = req.body || {};
    const key = process.env.TWELVEDATA_API_KEY;
    if (!key) return res.status(500).json({ error: "Missing TWELVEDATA_API_KEY" });

    const url = `${TD_BASE}?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&apikey=${encodeURIComponent(key)}&outputsize=450&format=JSON`;
    const rr = await fetch(url);
    if(!rr.ok) return res.status(502).json({ error:"TwelveData HTTP " + rr.status });
    const jj = await rr.json();
    if(!jj.values) return res.status(502).json({ error: jj.message || "No values" });
    const candles = norm(jj.values);

    const base = makeSignal(strategy, candles);

    // Optional AI rationale (server-side)
    const keyAI = process.env.OPENAI_API_KEY;
    let ai = "AI explanation disabled.";
    if (keyAI){
      const system = `You are Miguel FX Pro, a concise FX analyst. Produce one sentence: "SIGNAL: BUY/SELL/HOLD @ price | SL x | TP y — rationale". Avoid advice, only analysis.`;
      const payload = {
        model: "gpt-4o-mini",
        temperature: 0.2,
        messages: [
          { role: "system", content: system },
          { role: "user", content: `Strategy: ${strategy}\nSymbol: ${symbol} ${interval}\nBaseline: ${JSON.stringify(base)}\nExplain briefly (one sentence).`}
        ]
      };
      const or = await fetch("https://api.openai.com/v1/chat/completions", {
        method:"POST",
        headers:{ "Authorization":`Bearer ${keyAI}`, "Content-Type":"application/json" },
        body: JSON.stringify(payload)
      });
      if (or.ok){
        const j = await or.json();
        ai = j.choices?.[0]?.message?.content || ai;
      }else{
        ai = `LLM error ${or.status}`;
      }
    }
    res.json({ symbol, interval, strategy, baseline: base, ai });
  }catch(e){ res.status(500).json({ error: e.message }); }
});

// Serve client
app.use("/", express.static("../client"));

app.listen(PORT, ()=> console.log("MiguelFx Pro server on http://localhost:"+PORT));
