# Miguel FX Pro — Secure Signals

- Live TradingView chart in client
- Server-side strategies: **RSI, SMA 50/200, Breakout+ATR, Trendline, Head & Shoulders, ICT, SMC**
- TwelveData + OpenAI keys stored in **server/.env** only
- Endpoints: `/api/candles`, `/api/analyze`

## Run
```
cd server
cp .env.example .env    # add your real keys
npm i
npm run dev
```
Open http://localhost:8080

> NEVER paste your keys into the browser. Keep them in `.env` on the server.
